#- hacemos un meme con magick https://docs.ropensci.org/magick/
#- https://cran.r-project.org/web/packages/magick/vignettes/intro.html

library(magick)   #- pak::pak("magick")

# Carga la imagen de fondo
my_imagen <- magick::image_read("./imagenes/NV.jpg")

# Agrega texto en la parte superior de la imagen
my_texto <- "NV is the best!!!!"
my_imagen <- magick::image_annotate(my_imagen, 
                                    my_texto, 
                                    location = "+100+400", size = 90, color = "pink")
#- veamos el meme
print(my_imagen)
plot(my_imagen)

# Puedes guardar la imagen/meme resultante
# magick::image_write(my_imagen, "./imagenes/meme_con_magick.jpg")



#- otras posibilidades con el pkg "magick" -------------------------------------

# Rotar la imagen 
my_imagen_rotada <- image_rotate(my_imagen, 60)
plot(my_imagen_rotada)

# Cambia la resolución de la imagen
my_imagen_redimensionada <- image_scale(my_imagen, "30x30")
plot(my_imagen_redimensionada)

#- recortar
imagen_recortada <- image_crop(my_imagen, geometry = "400x600")
plot(imagen_recortada)

#- COMBINAR imágenes ----------------
#- primero cargamos otra imagen
frink <- image_read("https://jeroen.github.io/images/frink.png")
plot(frink)

#- las combinamos
dos_imagenes <- c(my_imagen, frink)
dos_imagenes <- image_mosaic(dos_imagenes)
plot(dos_imagenes)



#- se puede hacer mas cosas: aplicar filtros, combinar,  etc....
#- https://cran.r-project.org/web/packages/magick/vignettes/intro.html

