#- https://blog.ephorie.de/create-bart-simpson-blackboard-memes-with-rlibrary(meme)

#- el meme de Bart es esencial para dar consejos en clase y en unas slides
my_ruta <- "http://free-extras.com/pics/b/bart_simpson_chalkboard-5157.gif"

my_ruta <- "./imagenes/bart_simpson_chalkboard-5157.gif"
my_ruta <- here::here("imagenes", "bart_simpson_chalkboard-5157.gif")



meme::meme(my_ruta, "Al instalar paquetes .... \n  ... siempre sesión LIMPIA!!")


meme::meme(my_ruta, font = "Comic Sans MS", upper = "Please, \n deja los Rprojects \n en el escritorio!!!")


meme::meme(my_ruta, 
           font = "Impact", 
           color = "blue",
           bgcolor = "orange", r = 0.2,
           upper = "Please, configura tu RStudio", 
           lower = "Save workspace? Never \n \n save code? as UTF-8",
           vjust = 0.2)

