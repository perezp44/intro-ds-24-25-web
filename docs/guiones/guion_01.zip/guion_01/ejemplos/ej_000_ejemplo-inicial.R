#- Ejemplo nº 00
#- ejemplo simple para familiarizarse un poco con el entorno de RStudio y la sintaxis de R
#- este ejemplo, "ejemplifica" qué es la Ciencia de Datos. Se muestran las etapas típicas de un análisis de datos
#- las etapas básicamente son cinco: 1) importar/cargar datos, 2) arreglar los datos 3) análisis exploratorio 4) Modelización y 5) presentación de resultados


#- cargamos paquetes en memoria (antes tienes que haberlos instalado en tu PC)
library(tidyverse)  #- install.packages("tidyverse")
library(ggthemes)   #- #install.packages("ggthemes")

#- Etapa 1: importar/cargar datos ---------------------------------------------------------
#- cargamos 2 conjuntos de datos

emisiones <- rio::import("./datos/emisiones.xlsx") #- está en nuestro ordenador

temperaturas <- rio::import("https://raw.githubusercontent.com/perezp44/archivos_download/master/df_temperaturas.csv")


#- Etapa 2: arreglamos un poco los datos ---------------------------------------
temperaturas <- temperaturas %>%
                mutate(celsius = (temp_1 - 32)* 5/9) #- creamos la v. "celsius" 

temperaturas <- temperaturas %>% 
                select(year, celsius)     #- seleccionamos lo q nos hace falta

#- fusionamos las 2 tablas  (dataframes) de datos 
datos <- inner_join(emisiones, temperaturas)

#- Etapa 3: análisis exploratorio ----------------------------------------------

# hacemos gráficos con R-base 
plot(datos$CO2, datos$celsius)

#- hacemos gráficos con el pkg ggplot2 
ggplot(datos, aes(CO2, celsius)) + geom_point()


#- hacemos más gráficos con ggplot2 
ggplot(datos, aes(CO2, celsius)) + 
  geom_point() + 
  geom_smooth()


ggplot(datos, aes(CO2, celsius)) + 
  geom_point() + 
  geom_smooth(method = "lm", colour = "red")


ggplot(datos, aes(CO2, celsius)) + 
  geom_point() + 
  geom_smooth(method = "lm") +
    labs(title = "Temperatura vs. CO2",
         subtitle = "1959-2020",
         caption = "https://go.nasa.gov/2r8ryH1",
         x = "Nivel de CO2")


#- veamos mas themes() 
# https://yutannihilation.github.io/allYourFigureAreBelongToUs/ggthemes/
# https://exts.ggplot2.tidyverse.org/gallery/        #- pegadle un vistazo a esta gallery


my_plot <- ggplot(datos, aes(CO2, celsius)) + 
  geom_point() + 
  geom_smooth(method = "lm") +
    labs(title = "Temperatura vs. CO2",
         subtitle = "1959-2018",
         caption = "https://go.nasa.gov/2r8ryH1",
         x = "Nivel de CO2")


my_plot + theme_economist()

my_plot + theme_stata()

my_plot + theme_excel()

#- TAREA: poner la linea de regresión en "my_plot" de color verde [pista: colour = "green"]



#- Etapa 4): Modelización ------------------------------------------------------

#- planteamos y estimamos un modelo lineal
lm(formula = celsius ~ CO2, data = datos)

my_model <- lm(celsius ~ CO2, datos)
summary(my_model)



#- Etapa 5): Presentación de resultados ----------------------------------------
#- para hacer tablas hay multitud de paquetes. Por ejemplo
library(jtools)        #- install.packages("jtools")
jtools::summ(my_model)
summ(my_model, confint = TRUE, digits = 3) #- con intervalo de confianza



#- Más TAREAS: -----------------------------------------------------------------
#- hagamos el gráfico interactivo

plotly::ggplotly(my_plot)

#- una tabla interactiva

DT::datatable(datos)


