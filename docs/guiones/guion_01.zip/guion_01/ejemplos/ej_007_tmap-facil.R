#- bookdown: https://r-tmap.github.io/tmap-book/nutshell.html
#- https://cran.r-project.org/web/packages/tmap/vignettes/tmap-getstarted.html
library(tmap)  #- https://mtennekes.github.io/tmap/reference/qtm.html

#- el pkh tmap viene con algunos datos
data(World, rivers, metro) #- hacemos accesibles 3 conjuntos de datos (df's)

#  es muy fácil hacer un mapa con la función qtm()
qtm(World)

# coropletas
qtm(World, fill = "economy")
qtm(World, fill = "economy", format = "World", style = "col_blind", projection = "+proj=eck4")


# choropleth with way more specifications
qtm(World, fill="HPI", fill.n = 9, fill.palette = "div",
    fill.title = "Happy Planet Index", fill.id = "name", 
    style = "gray", format = "World", projection = "+proj=eck4")

# this map can also be created with the main plotting method,
#- qtm() es para hacer quick graphs. Generalmente se usa está sintaxis con tmap
tm_shape(World) +
    tm_polygons("HPI") +
    tm_layout(bg.color = "skyblue")

 tm_shape(World, projection = "+proj=eck4") +
    tm_polygons("HPI", n = 9, palette = "div", title = "Happy Planet Index", id = "name") +
    tm_style("gray") +
    tm_format("World")


#- con tmap se pueden hacer gráficos interactivos
#- tmap_mode("plot") 
tmap_mode("view")  


# dot map
qtm(metro, bbox = "China")
 
# without arguments, a plain interactive map is shown (si the mode is set to view)
qtm()
  
# search query for OpenStreetMap nominatim
qtm("Valencia")


#- bubble map con qtm()
qtm(World, borders = NULL) + 
    qtm(metro, symbols.size = "pop2010", 
        symbols.title.size= "Metropolitan Areas", 
        symbols.id= "name",
        format = "World")

