#- Ejemplo nº 01: vamos a hacer memes con el pkg "meme"
#- repo del paquete:  https://github.com/GuangchuangYu/meme/

#- Para poder usar el paquete, este tiene q estar instalado y cargado
library(meme)    #- install.packages("meme")


#- primer meme: ----------------------------------------------------------------
#- la foto esta en la carpeta:  ./imagenes/
ruta_a_imagen_1 <- "./imagenes/success.jpg"
ruta_a_imagen_2 <- "./imagenes/angry8.jpg"



meme(ruta_a_imagen_1, "SÍ q puedes!!!")


meme::meme(img = ruta_a_imagen_1,
           upper = "SÍ q puedes!!!")


meme::meme(img = ruta_a_imagen_2,
           upper = "SÍ q puedes!!!")


meme::meme(img = ruta_a_imagen_2,
           upper = "SÍ q puedes!!!",
           lower = "Tú puedes aprender R!!", 
           size = 2.0, 
           color = "purple")

meme(ruta_a_imagen_2, "SÍ q puedes!!!", "Tú puedes aprender R!!", 2.0, "purple")



#- segundo meme: ---------------------------------------------------------------
#- usamos una foto que está en internet 
ruta_a_imagen <- "https://i1.wp.com/production-wordpress-assets.s3.amazonaws.com/blog/wp-content/uploads/2013/03/wisdom_of_the_ancients-1.png?resize=485%2C270&ssl=1"

meme(ruta_a_imagen, "SÍ q puedes!!!", "Tú puedes aprender R!!", size = 2.0 , color = "purple")

#- grabamos el meme? -----------------------------------------------------------
my_meme <- meme(ruta_a_imagen_1, "SÍ q puedes!!!")

meme::ggsave("meme_01.png", my_meme, width = 6, height = 6, dpi = 300)

#- vamos a grabarlo en la carpeta ./imagenes/







#- Por cierto, hay paquetes más completos para hacer memes, pero este seguro que nos funcionaba. Si te interesa el tema mira este post: http://jenrichmond.rbind.io/post/making-memes-in-r/
#- entre otros paquetes, habla del pkg memer: https://github.com/sctyner/memer

#- pkg memer -------------------------------------------------------------------
#- devtools::install_github("sctyner/memer")
library(memer)
meme_list() #- lista de memes


# Creando memes con el pkg "memer"
meme_get("DistractedBf") |> meme_text_distbf("tidyverse", "new R users", "base R")

meme_explain("DistractedBf") #- podemos ver la historia/origen de un meme

memer::meme_get("AgnesWink") |> memer::meme_text_bottom("No hace falta que curreís en casa, \n con las clases sobra!!!")

meme_get("AnakinPadmeRight") 
